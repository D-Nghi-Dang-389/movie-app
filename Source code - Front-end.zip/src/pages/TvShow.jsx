
import TvShowList from '../components/TvShowList';

const TvShow = () => (
  <TvShowList category="tv" title="All TV Shows" />
);

export default TvShow;

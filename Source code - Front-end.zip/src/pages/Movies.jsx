import MovieList from "../components/MovieList";

const Movies = () => (
  <MovieList category="movie" title="All Movies" />
);

export default Movies;

